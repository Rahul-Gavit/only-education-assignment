import React from "react";

const quizzes = () => {
  return <div>quizzes</div>;
};

export default quizzes;
